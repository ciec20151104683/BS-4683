function checkDetails(){
	alert(123);
}