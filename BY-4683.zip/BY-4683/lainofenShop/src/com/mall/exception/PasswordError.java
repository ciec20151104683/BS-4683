package com.mall.exception;

public class PasswordError extends RuntimeException {

	public PasswordError(String message) {
		super(message);
	}
}
