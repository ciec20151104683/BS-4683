package com.mall.dao;

public interface AdminSuperType {

}
