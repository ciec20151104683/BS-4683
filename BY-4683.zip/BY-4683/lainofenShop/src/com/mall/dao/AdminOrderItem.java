package com.mall.dao;

public interface AdminOrderItem {

}
