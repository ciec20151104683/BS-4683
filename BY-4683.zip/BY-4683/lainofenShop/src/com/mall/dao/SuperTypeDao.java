package com.mall.dao;

import java.util.List;

public interface SuperTypeDao {
	//获取所有大类
	public List showAllSuperType();
}
