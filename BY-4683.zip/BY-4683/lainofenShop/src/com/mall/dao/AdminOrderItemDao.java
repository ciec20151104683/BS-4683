package com.mall.dao;

public interface AdminOrderItemDao {

}
