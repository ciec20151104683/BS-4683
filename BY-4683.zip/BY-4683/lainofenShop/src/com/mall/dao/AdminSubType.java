package com.mall.dao;

public interface AdminSubType {

}
