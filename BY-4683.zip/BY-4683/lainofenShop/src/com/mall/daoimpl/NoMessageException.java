package com.mall.daoimpl;

public class NoMessageException extends RuntimeException{
	public NoMessageException(String message){
		super(message);
	}
}
