package com.mall.daoimpl;

public class NoRelativeGoodsException extends RuntimeException{
	public NoRelativeGoodsException(String message){
		super(message);
	}
}
