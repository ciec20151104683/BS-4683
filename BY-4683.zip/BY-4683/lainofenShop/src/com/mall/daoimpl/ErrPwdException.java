package com.mall.daoimpl;

public class ErrPwdException extends RuntimeException {
	public ErrPwdException(String message){
		super(message);
	}
}
