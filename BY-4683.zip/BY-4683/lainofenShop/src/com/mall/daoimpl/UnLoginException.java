package com.mall.daoimpl;

public class UnLoginException extends RuntimeException{

	public UnLoginException(String message){
		super(message);
	}
}
