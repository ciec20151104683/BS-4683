package com.mall.po;

public class AdminType {
	
	private int adminTypeId;

	private String adminTypeName;

	public int getAdminTypeId() {
		return adminTypeId;
	}

	public void setAdminTypeId(int adminTypeId) {
		this.adminTypeId = adminTypeId;
	}

	public String getAdminTypeName() {
		return adminTypeName;
	}

	public void setAdminTypeName(String adminTypeName) {
		this.adminTypeName = adminTypeName;
	}



}
